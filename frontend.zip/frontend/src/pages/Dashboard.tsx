export default function Dashboard() {
  return (
    <section className="card">
      <h2>Dashboard (MVP)</h2>
      <p>Track quick stats here (stub):</p>
      <ul>
        <li>Scenarios generated: 3</li>
        <li>Assessments submitted: 2</li>
        <li>Avg score: 0.78</li>
      </ul>
    </section>
  )
}
